public class State {

    //Consists of location and information
    private LocationInterface loc;
    private Information info;

    private String direc = "";

    public State(Information info, LocationInterface loc){
        this.info = info;
        this.loc = loc;
        info.setS(this);
    }

    public State(Information info, LocationInterface loc, String direc){
        this.info = info;
        this.loc = loc;
        info.setS(this);
        this.direc = direc;
    }

    public LocationInterface getLoc(){
        return loc;
    }

    public Information getInfo(){
        return info;
    }

    public void setInfo(Information info) {
        this.info = info;
    }

    public void setLoc(LocationInterface loc) {
        this.loc = loc;
    }

    public boolean doesNotEqual(State given){

        return (this.getLoc() != given.getLoc() || !this.direc.equals(given.direc));
    }

    @Override
    public String toString() {
        return loc.toString() + " direction: " + direc;
    }
}
