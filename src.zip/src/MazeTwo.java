import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MazeTwo implements MazeInterface {

    private int[][] coord;
    private State startState;
    private MazeTwoLocation[][] allLoc = new MazeTwoLocation[20][21];
    public MazeTwoTransitions[][] allTransit = new MazeTwoTransitions[20][21];

    public MazeTwo() throws FileNotFoundException {

        //Reads MazeTwo file
        File m2 = new File("C:\\Users\\miran\\IdeaProjects\\COSC112\\FinalProject\\out\\production\\FinalProject\\MazeTwo.txt");

        Scanner readFile = new Scanner(m2);

        try {
            readFile = new Scanner(m2);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        coord = new int[20][21];

        int row = coord.length;
        int column = coord[0].length;

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {

                coord[i][j] = readFile.nextInt();

                //If goes in red, blue, yellow order, is a possible transition


                //New row index
                int rI = i ;

                //New col index
                int cI = j ;

                //Get all possible locations
                MazeTwoLocation currentLoc = new MazeTwoLocation(i, j);
                allLoc[i][j] = currentLoc;

                //Get all possible transitions
                MazeTwoTransitions tr = new MazeTwoTransitions(currentLoc);
                allTransit[i][j] = tr;



            }

        }

        startState = new State(new Information(null), allLoc[17][9]);
        MazeTwoTransitions.goal = allLoc[17][9];
        allLoc[17][9].setGoalReached(true);

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                int currentNum = coord[i][j];

                //Generate all possible transitions from the locations

            }
        }
    }

    public int[][] getCoord() {
        return coord;
    }

    //Returns start state
    @Override
    public State startState() {

        return startState;
    }
}