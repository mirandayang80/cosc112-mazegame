public interface MazeInterface {

    public State startState();

}


