import java.util.ArrayList;

public class MazeTwoLocation extends MazeOneLocation implements LocationInterface {

    //Contains list of transitions
    private ArrayList<TransitionInterface> possibleMOT;
    private boolean goalReached;
    private int rowIndex;
    private int columnIndex;
    private int color;

    public MazeTwoLocation(int rowIndex, int columnIndex) {
        super(rowIndex, columnIndex);
        this.rowIndex = rowIndex;
        this.columnIndex = columnIndex;
        possibleMOT = new ArrayList<>();
    }

    public ArrayList<TransitionInterface> getPossibleMOT(State s){
        return possibleMOT;
    }

    public void addPossibleMOT(MazeOneTransitions toAdd){

        possibleMOT.add(toAdd);

    }

    public int getColumnIndex() {
        return columnIndex;
    }

    public int getRowIndex() {
        return rowIndex;
    }


    public void setColumnIndex(int columnIndex) {
        this.columnIndex = columnIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public boolean isGoalReached() {
        return goalReached;
    }

    @Override
    public String getDirection() {
        return null;
    }

    public void setGoalReached(boolean goalReached) {
        this.goalReached = goalReached;
    }

    //Check if MazeTwoLocation are the same (not necessarily same transitions)
    public boolean equalLoc(MazeTwoLocation otherLoc) {
        return (rowIndex == otherLoc.rowIndex && columnIndex == otherLoc.columnIndex);
    }

    public boolean completelyEqual(MazeTwoLocation otherLoc) {

        boolean eqL = equalLoc(otherLoc);

        boolean transitionEqual = true;

        for (int i = 0; i < possibleMOT.size(); i++) {
            if (possibleMOT.get(i) != otherLoc.possibleMOT.get(i)) {
                transitionEqual = false;
            }
        }

        return eqL && transitionEqual;

    }

    public String toString(){
        return "Row: " + rowIndex + "\n" + "Column: " + columnIndex;
    }

}
